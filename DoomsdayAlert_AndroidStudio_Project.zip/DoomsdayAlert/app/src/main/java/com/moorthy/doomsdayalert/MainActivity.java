package com.moorthy.doomsdayalert;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText movieInput, urlInput;
    private TextView status;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        requestNotificationPermission();

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24, 28, 24, 24);
        page.setBackgroundColor(0xFF10131B);

        TextView title = new TextView(this);
        title.setText("DOOMSDAY ALERT");
        title.setTextSize(26);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        page.addView(title, match());

        TextView sub = new TextView(this);
        sub.setText("BookMyShow • Rakki Cinemas, OMR");
        sub.setTextSize(16);
        sub.setTextColor(0xFFB9C2D0);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 12, 0, 24);
        page.addView(sub, match());

        movieInput = new EditText(this);
        movieInput.setSingleLine(true);
        movieInput.setText(prefs.getString("movie", "Avengers: Doomsday"));
        movieInput.setHint("Movie title");
        page.addView(movieInput, match());

        urlInput = new EditText(this);
        urlInput.setText(prefs.getString("url",
            "https://in.bookmyshow.com/cinemas/chennai/rakki-cinemas-omr-kelambakkam/buytickets/rakk"));
        urlInput.setHint("BookMyShow theatre URL");
        urlInput.setTextColor(0xFFFFFFFF);
        urlInput.setHintTextColor(0xFF8892A0);
        page.addView(urlInput, match());

        status = new TextView(this);
        status.setText("Monitoring is OFF. Start monitoring while connected to the internet.");
        status.setTextColor(0xFFE4E8EF);
        status.setPadding(0, 22, 0, 18);
        page.addView(status, match());

        Button start = button("START MONITORING");
        start.setOnClickListener(v -> {
            saveSettings();
            Intent service = new Intent(this, MonitorService.class);
            service.setAction(MonitorService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
            else startService(service);
            status.setText("Monitoring ON • checks approximately every 5 minutes while Android allows it.");
            Toast.makeText(this, "Monitoring started", Toast.LENGTH_SHORT).show();
        });
        page.addView(start, match());

        Button stop = button("STOP MONITORING");
        stop.setOnClickListener(v -> {
            Intent service = new Intent(this, MonitorService.class);
            service.setAction(MonitorService.ACTION_STOP);
            startService(service);
            status.setText("Monitoring is OFF.");
        });
        page.addView(stop, match());

        Button test = button("TEST LOUD ALARM");
        test.setOnClickListener(v -> {
            Intent service = new Intent(this, MonitorService.class);
            service.setAction(MonitorService.ACTION_TEST_ALARM);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
            else startService(service);
        });
        page.addView(test, match());

        Button open = button("OPEN BOOKMYSHOW");
        open.setOnClickListener(v -> {
            saveSettings();
            Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(urlInput.getText().toString().trim()));
            startActivity(browser);
        });
        page.addView(open, match());

        TextView note = new TextView(this);
        note.setText("Important: this app checks the public theatre page; it does not use an official BookMyShow API. BookMyShow may block automated requests or change its page. A match is a possible booking signal, not a guaranteed confirmation. Verify the show on BookMyShow.");
        note.setTextColor(0xFFFFCC80);
        note.setTextSize(13);
        note.setPadding(0, 22, 0, 0);
        page.addView(note, match());

        setContentView(page);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    private void saveSettings() {
        prefs.edit()
            .putString("movie", movieInput.getText().toString().trim())
            .putString("url", urlInput.getText().toString().trim())
            .apply();
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        return b;
    }

    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
    }
}
