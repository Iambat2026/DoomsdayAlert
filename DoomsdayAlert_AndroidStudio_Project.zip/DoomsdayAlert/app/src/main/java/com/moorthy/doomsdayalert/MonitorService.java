package com.moorthy.doomsdayalert;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

public class MonitorService extends Service {
    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";
    public static final String ACTION_TEST_ALARM = "TEST_ALARM";
    public static final String ACTION_STOP_ALARM = "STOP_ALARM";
    private static final String CHANNEL_MONITOR = "monitor_channel";
    private static final String CHANNEL_ALERT = "alert_channel";
    private static final int NOTIFICATION_ID = 41;
    private static final long INTERVAL = 5 * 60 * 1000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private MediaPlayer player;
    private boolean monitoring = false;
    private boolean alerted = false;
    private PowerManager.WakeLock wakeLock;

    private final Runnable checkRunnable = new Runnable() {
        @Override public void run() {
            if (!monitoring) return;
            executor.execute(() -> checkPage());
            handler.postDelayed(this, INTERVAL);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannels();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP_ALARM.equals(action)) {
            stopAlarm();
            return START_STICKY;
        }
        if (ACTION_STOP.equals(action)) {
            monitoring = false;
            handler.removeCallbacks(checkRunnable);
            stopAlarm();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        startForeground(NOTIFICATION_ID, buildMonitorNotification("Starting monitor…"));
        if (ACTION_TEST_ALARM.equals(action)) {
            raiseAlarm("Alarm test", "This is how the booking alert will sound.");
            return START_NOT_STICKY;
        }
        if (!monitoring) {
            monitoring = true;
            alerted = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("already_alerted", false);
            acquireWakeLock();
            handler.removeCallbacks(checkRunnable);
            handler.post(checkRunnable);
        }
        return START_STICKY;
    }

    private void checkPage() {
        SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        String movie = p.getString("movie", "Avengers: Doomsday");
        String page = p.getString("url", "");
        if (movie == null || movie.trim().length() == 0 || page == null || !page.startsWith("https://")) {
            updateMonitor("Set a valid movie title and HTTPS page URL.");
            return;
        }
        HttpURLConnection connection = null;
        try {
            URL url = new URL(page);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(20000);
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
            connection.setRequestProperty("Accept-Language", "en-IN,en;q=0.9");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) {
                updateMonitor("BookMyShow returned HTTP " + code + ". Will retry.");
                return;
            }
            InputStream in = connection.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int n, total = 0;
            while ((n = in.read(buffer)) > 0 && total < 2 * 1024 * 1024) {
                out.write(buffer, 0, n);
                total += n;
            }
            in.close();
            String html = new String(out.toByteArray(), "UTF-8").toLowerCase(Locale.ROOT);
            String key = movie.toLowerCase(Locale.ROOT);
            boolean titleFound = html.contains(key);
            // Conservative heuristic: title must appear with a booking/show availability signal.
            boolean availabilitySignal = html.contains("available") ||
                html.contains("fast filling") || html.contains("book tickets") ||
                Pattern.compile("\\b[0-1]?[0-9]:[0-5][0-9]\\s*(am|pm)\\b").matcher(html).find();
            if (titleFound && availabilitySignal && !alerted) {
                alerted = true;
                p.edit().putBoolean("already_alerted", true).apply();
                raiseAlarm("AVENGERS: DOOMSDAY MAY BE OPEN!",
                    "Rakki Cinemas listing contains the movie and a show/availability signal. Verify now.");
            } else if (titleFound) {
                updateMonitor("Movie title found, but no clear booking signal yet.");
            } else {
                updateMonitor("Checked Rakki Cinemas. Booking signal not found yet.");
            }
        } catch (Exception e) {
            Log.e("DoomsdayAlert", "Page check failed", e);
            updateMonitor("Could not read the page. Retrying later.");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void updateMonitor(String message) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildMonitorNotification(message));
    }

    private Notification buildMonitorNotification(String message) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL_MONITOR) : new Notification.Builder(this);
        return b.setContentTitle("Doomsday Alert is monitoring")
            .setContentText(message).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi).setOngoing(true).build();
    }

    private void raiseAlarm(String title, String message) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Intent stop = new Intent(this, StopAlarmReceiver.class);
        PendingIntent stopPi = PendingIntent.getBroadcast(this, 2, stop,
            PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL_ALERT) : new Notification.Builder(this);
        Notification n = b.setContentTitle(title).setContentText(message)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX)
            .addAction(android.R.drawable.ic_media_pause, "STOP ALARM", stopPi)
            .setAutoCancel(false).build();
        nm.notify(99, n);
        try {
            stopAlarm();
            Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            player = new MediaPlayer();
            player.setDataSource(this, sound);
            player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception e) {
            Log.e("DoomsdayAlert", "Alarm playback failed", e);
        }
    }

    private void stopAlarm() {
        try {
            if (player != null) {
                if (player.isPlaying()) player.stop();
                player.release();
            }
        } catch (Exception ignored) { }
        player = null;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.cancel(99);
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            NotificationChannel monitor = new NotificationChannel(CHANNEL_MONITOR,
                "Monitoring status", NotificationManager.IMPORTANCE_LOW);
            NotificationChannel alert = new NotificationChannel(CHANNEL_ALERT,
                "Booking alarm", NotificationManager.IMPORTANCE_HIGH);
            alert.setDescription("Loud alert when a possible booking is detected.");
            nm.createNotificationChannel(monitor);
            nm.createNotificationChannel(alert);
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DoomsdayAlert:Monitor");
            wakeLock.acquire(6 * 60 * 60 * 1000L);
        } catch (Exception e) { Log.w("DoomsdayAlert", "Wake lock unavailable", e); }
    }

    private int immutableFlag() {
        return Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
    }

    @Override public void onDestroy() {
        monitoring = false;
        handler.removeCallbacks(checkRunnable);
        stopAlarm();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
