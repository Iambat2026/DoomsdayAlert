# Doomsday Alert (Android Studio project)

Preconfigured for:
- Movie: Avengers: Doomsday
- Theatre: Rakki Cinemas, OMR, Kelambakkam
- BookMyShow theatre listing: https://in.bookmyshow.com/cinemas/chennai/rakki-cinemas-omr-kelambakkam/buytickets/rakk

## Open and build
1. Extract the ZIP.
2. Open the `DoomsdayAlert` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Connect your Android phone with USB debugging enabled, or use Build > Build APK(s).
5. Install the debug APK from `app/build/outputs/apk/debug/app-debug.apk`.

## Use
1. Open Doomsday Alert and allow notifications.
2. Keep the movie title and theatre URL as configured.
3. Tap START MONITORING. Keep the persistent monitoring notification visible.
4. Tap TEST LOUD ALARM once to confirm your phone's alarm volume/settings.
5. When a possible listing match is detected, a looping alarm starts. Stop it using STOP ALARM in the alert notification.
6. Tap OPEN BOOKMYSHOW to verify and book.

## Important limitations
- BookMyShow does not provide a public consumer API for this use. This project checks the public theatre webpage and uses a heuristic (movie title plus an availability/showtime signal). It may miss listings, produce false positives, or fail if BookMyShow blocks automated requests, requires JavaScript, or changes its website.
- This is an unofficial personal-use helper, not affiliated with BookMyShow. Respect BookMyShow's terms and do not increase request frequency aggressively.
- The service checks about every five minutes while Android keeps it running. Android/OEM battery management, force-stop, reboot, network loss, and foreground-service rules can interrupt it. Exempt the app from battery optimization if your phone offers that setting. Reopen and start monitoring after reboot or if Android stops it.
- Alert detection is not a guarantee that tickets are actually purchasable. Always verify the live show listing in BookMyShow.
- Android 13+ requires notification permission. Alarm sound also depends on phone volume, Do Not Disturb, and notification/channel settings.
- Target SDK is 34 to keep this sample compatible with the included foreground data-sync service declaration. Update SDK and service strategy before Play Store distribution.

## Reset after alert
The app stores an `already_alerted` flag to avoid repeatedly sounding. Clear app storage or reinstall to reset it for another test cycle. (A future version can add a reset button.)
